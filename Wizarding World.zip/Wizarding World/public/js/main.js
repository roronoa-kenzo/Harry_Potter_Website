// Création d'un objet "els" pour stocker les éléments HTML de l'interface utilisateur
const els = {
    welcomeScreen: null,
    questionScreen: null,
    endScreen: null,
    welcomeBtn: null,
    answers: null,
    endBtn: null,
    answersContainer: null
};

// Variable pour suivre l'indice de la question actuelle
let questionIndex = 0;

// Un tableau d'objets contenant des questions et leurs réponses possibles
const questions = [{
    question: 'Quelle mots te parle le plus ? ?',
    answers: [{
        title: 'Courage',
        house: 'gryffondor'
    }, {
        title: 'Pouvoir',
        house: 'slytherin'
    }, {
        title: 'Sagesse',
        house: 'ravenclaw'
    }, {
        title: 'Confiance',
        house: 'hufflepuff'
    }]
},
{
    question: 'Une personne te fait du mal, que fait tu ?',
    answers: [{
        title: 'Tu le défie',
        house: 'gryffondor'
    }, {
        title: 'Tu prepare une vengeance',
        house: 'slytherin'
    }, {
        title: 'tu porte plainte au directeur',
        house: 'ravenclaw'
    }, {
        title: 'Tu le pardonne',
        house: 'hufflepuff'
    }]
},
{
    question: 'Quel est ton animal magique favori ?',
    answers: [{
        title: 'Hippogriffe',
        house: 'hufflepuff'
    }, {
        title: 'Phénix',
        house: 'gryffondor'
    }, {
        title: 'Sombral',
        house: 'ravenclaw'
    }, {
        title: 'Dragon',
        house: 'slytherin'
    }]
}
];

// Un tableau pour enregistrer les réponses de l'utilisateur
const recordedAnswers = [];

// Fonction d'initialisation appelée lorsque la page est chargée
const init = () => {
    console.log('Page has loaded');

    // Sélection des éléments HTML et stockage dans l'objet "els"
    els.welcomeScreen = document.querySelector('.welcome-screen');
    els.questionScreen = document.querySelector('.question-screen');
    els.endScreen = document.querySelector('.end-screen');
    els.welcomeBtn = els.welcomeScreen.querySelector('button');
    els.endBtn = els.endScreen.querySelector('button');
    els.answersContainer = els.questionScreen.querySelector('ul');

    // Ajout d'écouteurs d'événements pour les boutons de démarrage et de fin
    els.welcomeBtn.addEventListener('click', () => {
        displayScreen('question');
        displayQuestion(questionIndex);
    });
    els.endBtn.addEventListener('click', () => {
        displayScreen('welcome');
        questionIndex = 0;
    });

    // Ajout d'un écouteur d'événements pour gérer les réponses sélectionnées
    els.answersContainer.addEventListener('click', ({ target }) => {
        if (target.tagName !== 'LI') {
            return;
        }
        const house = target.getAttribute('house');
        recordedAnswers.push(house);

        questionIndex++;

        if (questionIndex >= questions.length) {
            calculateScore();
            displayScreen('end');
        } else {
            displayQuestion(questionIndex);
        }
    });
};

// Fonction pour calculer le résultat final basé sur les réponses enregistrées
const calculateScore = () => {
    const house = recordedAnswers.sort((a, b) => {
        return recordedAnswers.filter(answer => answer === a).length - 
        recordedAnswers.filter(answer => answer === b).length 
    }).pop();
    console.log('house', house);

    // Un objet associant les maisons à des noms de maisons
    const houseResult = {
        slytherin: 'Slytherin',
        hufflepuff: 'Hufflepuff',
        ravenclaw: 'Ravenclaw',
        gryffondor: 'Gryffindor'
    };

    // Affichage du résultat de la maison correspondante à l'écran de fin
    els.endScreen.querySelector('span').textContent = houseResult[house];

    console.log(houseResult);
};

// Fonction pour afficher une question à l'écran
const displayQuestion = (index) => {
    const currentQuestion = questions[index];

    const questionEl = els.questionScreen.querySelector('h2');

    // Création des éléments de réponse pour la question actuelle
    const answerEls = currentQuestion.answers.map((answer) => {
        const liEl = document.createElement('li');
        liEl.textContent = answer.title;
        liEl.setAttribute('house', answer.house);
        return liEl;
    });

    // Affichage de la question et des réponses
    questionEl.textContent = currentQuestion.question;
    els.answersContainer.textContent = '';
    els.answersContainer.append(...answerEls);
};

// Fonction pour afficher l'écran spécifié
const displayScreen = (screenName) => {
    els.welcomeScreen.style.display = 'none';
    els.questionScreen.style.display = 'none';
    els.endScreen.style.display = 'none';

    const screen = els[screenName + 'Screen'];
    screen.style.display = 'flex';
};

// Ajout d'un écouteur d'événements pour démarrer l'initialisation lorsque la page est chargée
window.addEventListener('load', init);


// Exemple d'utilisation de fetch pour envoyer des données au serveur
fetch('auth/house', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({ userHouse }) // Envoyez la maison attribuée à l'utilisateur
  })
  .then(response => {
    if (response.ok) {
      // La requête s'est terminée avec succès
      console.log('Maison enregistrée avec succès');
      // Effectuez toute action supplémentaire ici si nécessaire
    } else {
      // Gestion des erreurs en cas d'échec de la requête
      console.error('Échec de la requête.');
      throw new Error('Échec de la requête.');
    }
  })
  .catch(error => {
    // Gestion des erreurs
    console.error('Erreur lors de l\'enregistrement de la maison :', error);
  });
  


console.log(houseResult);

window.addEventListener('load', init);