const express = require('express');
const { isLoggedIn, AllLoggedIn, fetchComments, isLoggedInAsAdmin , Article, Article2, LatestArticle, News, CountUser, } = require('../controllers/auth');
const router = express.Router();
const { fetchMessages } = require('../controllers/auth');

// Route handler for the homepage
router.get('/', isLoggedIn,isLoggedInAsAdmin, LatestArticle, News,  (req, res) => {
  
  const admin = req.admin
  
  const news = req.News

  const latestArticle = req.LatestArticle

  const user = req.user;

  console.log(user);

  res.render('index' , {user, latestArticle, news, admin});
});

router.get('/shop', isLoggedIn, isLoggedInAsAdmin, Article, Article2, (req, res) => {
  const admin = req.admin

  const user = req.user;

  const article2 = req.Article2;

  const article = req.Article;

  console.log("article",article);

  console.log("article2", article2);

  res.render('shop', {user , article, article2, admin});
});

router.get('/test', isLoggedIn, isLoggedInAsAdmin, (req, res) => {
  const admin = req.admin

  const user = req.user;
  res.render('test-home', {user, admin}) ;
});

router.get('/profile', isLoggedIn, isLoggedInAsAdmin, (req, res) => {
  
  const admin = req.admin
  const user = req.user;
 res.render('profile' ,{user, admin})
});

router.get('/edit', isLoggedIn, isLoggedInAsAdmin, (req, res) => {
  
  const admin = req.admin
  const user = req.user;
 res.render('edit' ,{user, admin})
});

router.get('/register', (req, res) => {
  
  res.render('register');
});

router.get('/login', (req, res) => {
  
  res.render('login');
});

router.get('/test-maison', isLoggedIn, isLoggedInAsAdmin, (req, res) => {
  const admin = req.admin

  const user = req.user;
  res.render('test-maison', {user, admin});
});

/* ------------------------------------------Admin----------------------------------------- */

router.get('/admin', AllLoggedIn, isLoggedIn, isLoggedInAsAdmin ,CountUser,(req, res) => {
  const message = req.session.message;
  req.session.message = null; 

  const user = req.user;

  const admin = req.admin;

  const AllUser = req.AllUserExports ;

  const CountU = req.userCount 


  if (admin) {
    res.render('admin', { admin, user , AllUser ,message , CountU});
  } else {
    res.redirect('/');
  }
  
});

module.exports = router ;

