const mysql = require("mysql");
const jwt = require('jsonwebtoken');
const bcryptjs = require('bcryptjs');
const path = require('path');
const fs = require('fs');
const { promisify } = require('util');
const { validationResult } = require('express-validator');
const { log } = require("console");
const session = require('express-session');
const db = require('../config/db');
const bodyParser = require('body-parser');

//~Jolie Regex~ 
const emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
const passwordRegex = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$/;

exports.register = (req, res) => {
    const { username, email, password, passwordConfirm } = req.body;
    console.log('toto', req.body);


    // Vérification de la validité de l'email
    if (!emailRegex.test(email)) {
      return res.status(403).json({error:'Email invalide'});
    }

    // Vérification de la force du mot de passes
    if (!passwordRegex.test(password)) {
      return res.status(403).json({error:'le mot de passe doit avoir au moins 8 caracteres'});
    }
    

    // Vérification de la correspondance entre le mot de passe et sa confirmation
    if (password !== passwordConfirm) {
      return res.status(403).json({error:'le mot de passe ne correspond pas'});
    }

    db.query('SELECT UserEmail FROM user WHERE UserEmail = ?', [email], async (error, results) => {
        if (error) {
            console.log(error);
            return res.status(403).json({error:'erreur lors de la verification de l\'email'});
        }

        if (results.length > 0) {
            return res.status(403).json({error:'email already use'});
        } else {
            try {
                let hashedPassword = await bcryptjs.hash(password, 8);
                let img = 'defaultimg.png'
                db.query('INSERT INTO user SET ?', { UserName: username, UserEmail: email, UserPassword: hashedPassword, UserProfileImage: img, }, (error, results) => {
                    if (error) {
                        console.log(error);
                        return res.status(403).json({error:'erreur avec l\'enregistrement de l\'utilisateur'});;
                    }
                    return res.redirect(302, '/');
                });
            } catch (error) {
                console.log(error);
                return res.status(403).json({error:'erreur avec le hashage du password'});;
            }
        }
    });
};

//Login et Stockage dans la session
exports.login = async (req, res) => {
    try {
      const { email, password } = req.body;
  
      if (!email || !password) {
        return res.status(400).render('index', {
          message: 'Please fill in all fields',
        });
      }
  
      db.query('SELECT * FROM user WHERE UserEmail = ?', [email], async (error, results) => {
        if (!results || results.length === 0) {
          res.status(401).render({
            message: 'Email or Password incorrect',
          });
        } else {
          const isPasswordMatch = await bcryptjs.compare(password, results[0].UserPassword);
  
          if (isPasswordMatch) {
            const id = results[0].idUser;
  
            const token = jwt.sign({ id }, process.env.JWT_SECRET, {
              expiresIn: process.env.JWT_EXPIRES_IN,
            });
  
            // Store the token in the session
            req.session.token = token;
            
  
            // Store the success message in the session
            req.session.message = 'Login successful';
  


            // Redirect to the index page
            res.status(200).redirect(302, '/');
          } else {
            res.status(403).json({error:'invalide password'});
          }
        }
      });
    } catch (error) {
      console.log(error);
    }
  };

// Verification Du Stockage en Session du tokken
exports.isLoggedIn = async (req, res, next) => {
    if (req.session.token) {
        try {
            // Verify the token
            const decoded = await promisify(jwt.verify)(req.session.token, process.env.JWT_SECRET);

            // Find the user using your custom MySQL query
            db.query('SELECT * FROM user WHERE idUser = ?', [decoded.id], (error, result) => {
                if (!result || result.length === 0) {
                    return next();
                }

                // Set req.user to the user retrieved from the database
                req.user = result[0];
                
                return next();
            });
        } catch (error) {
            console.log(error);
            return next();
        }
    } else {
        next();
    }
};

exports.isLoggedInAsAdmin = async (req, res, next) => {
  if (req.session.token) {
    try {
      // Verify the token
      const decoded = await promisify(jwt.verify)(req.session.token, process.env.JWT_SECRET);

      // Find the user using your custom MySQL query
      db.query('SELECT * FROM user WHERE idUser = ?', [decoded.id], (error, result) => {
        if (!result || result.length === 0) {
          return next();
        }

        // Check if the user has the role of "admin"
        if (result[0].UserRoles === 'admin') {
          // Set req.user to the user retrieved from the database
          req.admin = result[0];
        }
        return next();
      });
    } catch (error) {
      console.log(error);
      return next();
    }
  } else {
    next();
  }
};

exports.logout = (req, res) => {
    // Clear the session token
    req.session.token = null;
  
    // Store the success message in the session
    req.session.message = 'Logout successful';
  
    // Redirect to the homepage or any desired route
    res.status(200).redirect('/');
  };


exports.Article = async (req, res, next) => {
        try {      
            db.query('SELECT * from article where id_categorie = 1', (error, result) => {
                if (!result || result.length === 0) {
                    return next();
                }               
                req.Article = result
                return next();
            });
        } catch (error) {
            console.log(error);
            return next();
        }
    
};

exports.Article2 = async (req, res, next) => {
  try {      
      db.query('SELECT * from article where id_categorie = 2', (error, result) => {
          if (!result || result.length === 0) {
              return next();
          }               
          req.Article2 = result
          return next();
      });
  } catch (error) {
      console.log(error);
      return next();
  }

};

exports.LatestArticle = async (req, res, next) => {
  try {      
      db.query('SELECT * from article ORDER BY id_article DESC LIMIT 3', (error, result) => {
          if (!result || result.length === 0) {
              return next();
          }               
          req.LatestArticle = result
          return next();
      });
  } catch (error) {
      console.log(error);
      return next();
  }

};

exports.News = async (req, res, next) => {
  try {      
      db.query('SELECT * from news ORDER BY id_news DESC LIMIT 3', (error, result) => {
          if (!result || result.length === 0) {
              return next();
          }               
          req.News = result
          return next();
      });
  } catch (error) {
      console.log(error);
      return next();
  }

};

//User Crud (Update Account & Delete Account)
exports.UpdateEmail = async (req, res) => {
  
  try {
    const { email, password } = req.body;

    if (!email && !password) {
    return res.status(400).render('edit', {
        message: 'Veuillez remplir au moins un champ',
    });
    }

    try {
    const decoded = await promisify(jwt.verify)(req.session.token, process.env.JWT_SECRET);
    const userId = decoded.id;

    db.query('SELECT * FROM user WHERE idUser = ?', [userId], async (error, result) => {
        if (error) {
        return res.status(500).render('edit', {
            message: 'Erreur lors de la mise à jour',
        });
        } else {
        if (!result) {
            return res.status(404).render('edit', {
            message: 'Utilisateur introuvable',
            });
        }

        let updateQuery = '';
        const updateValues = [];
        let hashedPassword;

        if (email) {
            updateQuery += 'UserEmail = ?,';
            updateValues.push(email);
        }

        if (password) {
          hashedPassword = await bcryptjs.hash(password, 8);
          updateQuery += 'UserPassword = ?,';
          updateValues.push(hashedPassword);
        }

        // Remove the trailing comma from updateQuery
        updateQuery = updateQuery.slice(0, -1);

        // Add the userId to updateValues
        updateValues.push(userId);

        // Perform the update operation in the database
        // Replace the code below with your actual update logic
        db.query('UPDATE user SET ' + updateQuery + ' WHERE idUser = ?', updateValues, (error, result) => {
            if (error) {
            return res.status(500).render('edit', {
                message: 'Erreur lors de la mise à jour',
            });
            } else {
            return res.redirect('/');
            }
        });
        }
    });
    } catch (error) {
    return res.status(401).render('edit', {
        message: 'Accès non autorisé',
    });
    }
} catch (error) {
    console.log(error);
}
};


exports.ProfilPic = async (req, res) => {
  const { filename } = req.file;
  const { userId, userImg } = req.body;
  console.log(filename);
  console.log(userId);
  console.log(userImg);

  // Step 1: Check if there is an image
  if (!filename) {
    req.session.message = 'No image uploaded';
    return res.redirect('/');
  }

  // Step 2: Update the user's profile image
  db.query(
    'UPDATE user SET UserProfileImage = ? WHERE idUser = ?',
    [filename, userId],
    (error) => {
      if (error) {
        console.log(error);
        req.session.message = 'Error updating the profile picture';
        return res.redirect('/');
      }

      // Step 3: Delete the old image (assuming the previous image is stored in the 'public/uploads/' directory)
      if (userImg) {
        const oldImagePath = path.join(__dirname, '..', 'public', 'uploads', userImg);
        fs.unlink(oldImagePath, (err) => {
          if (err) {
            console.log(err);
            // Handle the error or log it if necessary
          }
        });
      }

      req.session.messages = 'Profile picture updated successfully';
      return res.redirect('/');
    }
  );
};

exports.Delete = async (req, res) => {

  //Step 1 Get the UserId -_- 🤷 ET ARRETE D'ECRIRE ICI 
  const  UserId  = req.body.UserId;
  console.log(UserId)
  //Step 1 Bonus Verifier que l'user a un tokken
  
  //Step 2 Bye Bye User Je me souviens pas qu'on a un champs id en bdd mais bon on va dire c'est la fatigue
    db.query('DELETE FROM user WHERE idUser = ?', UserId, (err, result) => {
      if(err){
      console.log(err)
      return res.status(500).render('edit', {
        message: 'Erreur lors du delete',
    });
    }
    else{
      return res.redirect('/');
    }
    })
};

//--------------------------------Admin Crud
exports.CountUser = async (req, res, next) => {
  try {
    db.query('SELECT COUNT(*) AS userCount FROM user', (error, results) => {
      if (error) {
        console.log(error);
        return res.status(500).send('Erreur lors du comptage des utilisateurs');
      } else {
        const userCount = results[0].userCount;
        req.userCount = userCount;
        next()
      }
    });
  } catch (error) {
    console.log(error);
    return res.status(500).send('Erreur lors du comptage des utilisateurs');
  }
};

exports.AllLoggedIn = async (req, res, next) => {
  if (req.session.token) {
    try {
      // Find all users using the MySQL query
      db.query('SELECT * FROM user', (error, result) => {
        if (error) {
          console.log(error);
          return next();
        }
        // Set req.AllUserExports to the users retrieved from the database
        req.AllUserExports = result;
        return next();
      });
    } catch (error) {
      console.log(error);
      return next();
    }
  } else {
    next();
  }
};

exports.AdminDelete = async (req, res) => {

  //Step 1 Get the UserId -_- 🤷 ET ARRETE D'ECRIRE ICI 
  const  UserId  = req.body.UserId;
  
    db.query('DELETE FROM user WHERE idUser = ?', UserId, (err, result) => {
      if(err){
      console.log(err)
      return res.status(500).render('admin', {
        message: 'Erreur lors du delete',
    });
    }
    else{
      return res.redirect('/admin');
    }
    })
};

exports.AdminEdit = async (req, res) => {
  try {
    const { UserId, name, email, password, role } = req.body;

    if (!name && !email && !password && !role) {
      return res.status(400).render('Error');
    }

    try {
      // Fetch the user to be edited from the database
      db.query('SELECT * FROM user WHERE idUser = ?', UserId, async (error, result) => {
        if (error) {
          return res.redirect('/');
        } else {
          if (!result || result.length === 0) {
            return res.status(404).render('admin', {
              message: 'Utilisateur introuvable',
            });
          }

          let updateQuery = '';
          const updateValues = [];

          if (name) {
            updateQuery += 'UserName = ?,';
            updateValues.push(name);
          }

          if (email) {
            updateQuery += 'UserEmail = ?,';
            updateValues.push(email);
          }

          if (password) {
            const salt = await bcryptjs.genSalt(8);
            const hashedPassword = await bcryptjs.hash(password, salt);
            updateQuery += 'UserPassword = ?,';
            updateValues.push(hashedPassword);
          }

          if (role && role === 'admin') {
            updateQuery += 'UserRoles = ?,';
            updateValues.push(role);
          } else {
            updateQuery += 'UserRoles = NULL,';
          }

          // Remove the trailing comma from updateQuery
          updateQuery = updateQuery.slice(0, -1);

          // Add the user ID to updateValues
          updateValues.push(UserId);

          // Perform the update operation in the database
          db.query('UPDATE user SET ' + updateQuery + ' WHERE idUser = ?', updateValues, (error, result) => {
            if (error) {
              return res.redirect('/');
            } else {
              return res.redirect('/');
            }
          });
        }
      });
    } catch (error) {
      return res.redirect('/');
    }
  } catch (error) {
    console.log(error);
  }
};

exports.AllUser = async (req, res) => {

  try {
    // Fetch comments from the database with user information, including User.Roles and idMessage
    db.query('SELECT * FROM user', (error, results) => {
        if (error) {
          console.log(error);
          req.session.message = 'Failed to fetch comments';
          return res.redirect('/');
        }
      }
    );
  } catch (error) {
    console.log(error);
    req.session.message = 'Failed to fetch comments';
    res.redirect('/');
  }

};
//--------------------------------House-User

exports.HouseRegister = (req, res) => {
  const { userHouse } = req.body;

  // Vérifiez si l'utilisateur est authentifié (vous pouvez ajouter une vérification d'authentification ici)

  // Insérez la maison de l'utilisateur dans la base de données
  const sql = 'UPDATE user SET id_maison = ? WHERE idUser = ?';
  db.query(sql, [userId, userHouse], (err, result) => {
    if (err) {
      console.error('Erreur lors de l\'insertion en base de données :', err);
      res.status(500).json({ error: 'Erreur lors de l\'enregistrement de la maison' });
    } else {
      console.log('Maison enregistrée en base de données');
      res.status(200).json({ success: true });
    }
  });

};
